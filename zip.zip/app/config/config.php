<?php

define('base_url', 'http://localhost/bukita/public');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'belajar_buku');